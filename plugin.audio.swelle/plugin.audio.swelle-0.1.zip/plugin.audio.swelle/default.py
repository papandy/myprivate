url = 'http://www.schwarze-welle.de/play.m3u'
xbmc.Player().play(url)